from django.urls import path
from . import views

urlpatterns = [
    path('produto/<int:produto_id>/', views.exibir_produto, name='exibir_produto'),
    path('carrinho/', views.carrinho_compras, name='carrinho_compras'),
    # Outras rotas do aplicativo 'loja'
]