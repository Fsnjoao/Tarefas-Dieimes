from django.shortcuts import render
from django.http import HttpResponse

def exibir_produto(request, produto_id):
    # Lógica para exibir informações do produto com o ID fornecido
    return HttpResponse(f'Exibindo detalhes do produto {produto_id}')

def carrinho_compras(request):
    return render(request, 'loja/carrinho.html')

# Outras funções de visualização do aplicativo 'loja'
