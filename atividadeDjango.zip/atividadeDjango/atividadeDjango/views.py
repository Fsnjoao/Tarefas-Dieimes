from django.shortcuts import render

def pagina1(request):
    return render(request, 'atividadeDjango/pagina1.html')

def pagina2(request):
    return render(request, 'atividadeDjango/pagina2.html')

# Outras funções de visualização do aplicativo 'atividadeDjango'
