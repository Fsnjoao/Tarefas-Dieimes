from django.urls import path
from . import views

urlpatterns = [
    path('', views.pagina1, name='pagina1_atividade'),  # Rota para a URL raiz
    path('pagina1/', views.pagina1, name='pagina1_atividade'),
    path('pagina2/', views.pagina2, name='pagina2_atividade'),
    # Outras rotas do aplicativo 'atividadeDjango'
]
